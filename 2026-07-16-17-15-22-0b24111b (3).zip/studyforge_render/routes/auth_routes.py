"""
StudyForge Auth Routes
Handles signup, login, and user profile.
"""
from fastapi import APIRouter, HTTPException, status, Depends
from datetime import timedelta

from database import get_db
from models import SignupRequest, LoginRequest, TokenResponse
from auth import hash_password, verify_password, create_access_token, get_current_user_id
from config import ACCESS_TOKEN_EXPIRE_MINUTES

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


@router.post("/signup")
async def signup(req: SignupRequest):
    """
    Create a new user account.
    
    Request body:
        username, email, password, full_name (optional), branch (optional), year (optional)
    """
    db = get_db()
    
    # Check if email already exists
    existing = await db.users.find_one({"email": req.email})
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered",
        )
    
    # Check if username already exists
    existing_username = await db.users.find_one({"username": req.username})
    if existing_username:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already taken",
        )
    
    # Create user document
    user_doc = {
        "username": req.username,
        "email": req.email,
        "hashed_password": hash_password(req.password),
        "full_name": req.full_name,
        "branch": req.branch,
        "year": req.year,
        "avatar_url": "",
        "bio": "",
        "xp": 0,
        "level": 1,
        "badges": [],
        "reputation": 0,
        "is_premium": False,
        "created_at": None,
    }
    
    result = await db.users.insert_one(user_doc)
    user_id = str(result.inserted_id)
    
    # Generate JWT token
    token = create_access_token(
        data={"sub": user_id},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES),
    )
    
    return TokenResponse(
        access_token=token,
        token_type="bearer",
        user={
            "id": user_id,
            "username": req.username,
            "email": req.email,
            "full_name": req.full_name,
            "branch": req.branch,
            "year": req.year,
        }
    )


@router.post("/login")
async def login(req: LoginRequest):
    """
    Log in with email and password.
    Returns a JWT token and user info.
    """
    db = get_db()
    
    # Find user by email
    user = await db.users.find_one({"email": req.email})
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )
    
    # Verify password
    if not verify_password(req.password, user["hashed_password"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )
    
    user_id = str(user["_id"])
    
    # Generate JWT token
    token = create_access_token(
        data={"sub": user_id},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES),
    )
    
    return TokenResponse(
        access_token=token,
        token_type="bearer",
        user={
            "id": user_id,
            "username": user["username"],
            "email": user["email"],
            "full_name": user.get("full_name", ""),
            "branch": user.get("branch", ""),
            "year": user.get("year", 1),
            "avatar_url": user.get("avatar_url", ""),
            "bio": user.get("bio", ""),
            "xp": user.get("xp", 0),
            "level": user.get("level", 1),
            "reputation": user.get("reputation", 0),
            "badges": user.get("badges", []),
            "is_premium": user.get("is_premium", False),
        }
    )


@router.get("/profile")
async def get_profile(user_id: str = Depends(get_current_user_id)):
    """Get current user's profile."""
    db = get_db()
    from bson.objectid import ObjectId
    
    user = await db.users.find_one({"_id": ObjectId(user_id)})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {
        "id": str(user["_id"]),
        "username": user["username"],
        "email": user["email"],
        "full_name": user.get("full_name", ""),
        "avatar_url": user.get("avatar_url", ""),
        "bio": user.get("bio", ""),
        "branch": user.get("branch", ""),
        "year": user.get("year", 1),
        "xp": user.get("xp", 0),
        "level": user.get("level", 1),
        "badges": user.get("badges", []),
        "reputation": user.get("reputation", 0),
        "is_premium": user.get("is_premium", False),
    }
