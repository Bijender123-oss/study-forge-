"""
StudyForge Post Routes
Community feed: create, read, like, comment on posts.
"""
from fastapi import APIRouter, HTTPException, Query, Depends
from typing import Optional

from database import get_db
from models import CreatePostRequest, CreateCommentRequest
from auth import get_current_user_id
from bson.objectid import ObjectId

router = APIRouter(prefix="/api/posts", tags=["Community Feed"])


@router.get("/")
async def get_feed(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=50),
    branch: Optional[str] = None,
    post_type: Optional[str] = None,
):
    """
    Get community feed posts.
    """
    db = get_db()
    
    filter_query = {}
    if branch:
        filter_query["branch"] = branch
    if post_type:
        filter_query["post_type"] = post_type
    
    total = await db.posts.count_documents(filter_query)
    
    cursor = db.posts.find(filter_query)
    cursor = cursor.sort("created_at", -1)
    cursor = cursor.skip((page - 1) * limit).limit(limit)
    
    posts = []
    async for doc in cursor:
        posts.append({
            "id": str(doc["_id"]),
            "user_id": doc["user_id"],
            "username": doc["username"],
            "user_avatar": doc.get("user_avatar", ""),
            "post_type": doc["post_type"],
            "title": doc["title"],
            "content": doc["content"],
            "tags": doc.get("tags", []),
            "branch": doc.get("branch", ""),
            "likes": doc.get("likes", 0),
            "comments_count": doc.get("comments_count", 0),
            "saves_count": doc.get("saves_count", 0),
            "xp_reward": doc.get("xp_reward", 0),
            "created_at": doc["created_at"].isoformat() if doc.get("created_at") else None,
        })
    
    return {
        "posts": posts,
        "page": page,
        "limit": limit,
        "total": total,
        "total_pages": (total + limit - 1) // limit,
    }


@router.post("/")
async def create_post(
    req: CreatePostRequest,
    user_id: str = Depends(get_current_user_id),
):
    """Create a new post on the feed."""
    db = get_db()
    
    user = await db.users.find_one({"_id": ObjectId(user_id)})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    import datetime
    post_doc = {
        "user_id": user_id,
        "username": user["username"],
        "user_avatar": user.get("avatar_url", ""),
        "post_type": req.post_type,
        "title": req.title,
        "content": req.content,
        "tags": req.tags,
        "branch": req.branch,
        "likes": 0,
        "liked_by": [],
        "comments_count": 0,
        "saves_count": 0,
        "saved_by": [],
        "xp_reward": 10,
        "created_at": datetime.datetime.now(datetime.timezone.utc),
        "updated_at": datetime.datetime.now(datetime.timezone.utc),
    }
    
    result = await db.posts.insert_one(post_doc)
    
    await db.users.update_one(
        {"_id": ObjectId(user_id)},
        {"$inc": {"xp": 10}}
    )
    
    return {
        "id": str(result.inserted_id),
        "message": "Post created successfully",
        "xp_earned": 10,
    }


@router.get("/{post_id}")
async def get_post(post_id: str):
    """Get a single post by ID."""
    db = get_db()
    
    post = await db.posts.find_one({"_id": ObjectId(post_id)})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    comments = []
    cursor = db.comments.find({"post_id": post_id}).sort("created_at", 1)
    async for comment in cursor:
        comments.append({
            "id": str(comment["_id"]),
            "user_id": comment["user_id"],
            "username": comment["username"],
            "user_avatar": comment.get("user_avatar", ""),
            "content": comment["content"],
            "upvotes": comment.get("upvotes", 0),
            "is_ai_answer": comment.get("is_ai_answer", False),
            "created_at": comment["created_at"].isoformat() if comment.get("created_at") else None,
        })
    
    return {
        "id": str(post["_id"]),
        "user_id": post["user_id"],
        "username": post["username"],
        "user_avatar": post.get("user_avatar", ""),
        "post_type": post["post_type"],
        "title": post["title"],
        "content": post["content"],
        "tags": post.get("tags", []),
        "branch": post.get("branch", ""),
        "likes": post.get("likes", 0),
        "comments_count": post.get("comments_count", 0),
        "saves_count": post.get("saves_count", 0),
        "xp_reward": post.get("xp_reward", 0),
        "created_at": post["created_at"].isoformat() if post.get("created_at") else None,
        "comments": comments,
    }


@router.post("/{post_id}/like")
async def like_post(post_id: str, user_id: str = Depends(get_current_user_id)):
    """Toggle like on a post."""
    db = get_db()
    
    post = await db.posts.find_one({"_id": ObjectId(post_id)})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    liked_by = post.get("liked_by", [])
    
    if user_id in liked_by:
        await db.posts.update_one(
            {"_id": ObjectId(post_id)},
            {"$pull": {"liked_by": user_id}, "$inc": {"likes": -1}}
        )
        return {"liked": False, "likes": post["likes"] - 1}
    else:
        await db.posts.update_one(
            {"_id": ObjectId(post_id)},
            {"$push": {"liked_by": user_id}, "$inc": {"likes": 1}}
        )
        return {"liked": True, "likes": post["likes"] + 1}


@router.post("/{post_id}/save")
async def save_post(post_id: str, user_id: str = Depends(get_current_user_id)):
    """Toggle save on a post."""
    db = get_db()
    
    post = await db.posts.find_one({"_id": ObjectId(post_id)})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    saved_by = post.get("saved_by", [])
    
    if user_id in saved_by:
        await db.posts.update_one(
            {"_id": ObjectId(post_id)},
            {"$pull": {"saved_by": user_id}, "$inc": {"saves_count": -1}}
        )
        return {"saved": False, "saves_count": post["saves_count"] - 1}
    else:
        await db.posts.update_one(
            {"_id": ObjectId(post_id)},
            {"$push": {"saved_by": user_id}, "$inc": {"saves_count": 1}}
        )
        return {"saved": True, "saves_count": post["saves_count"] + 1}


@router.post("/{post_id}/comments")
async def create_comment(
    post_id: str,
    req: CreateCommentRequest,
    user_id: str = Depends(get_current_user_id),
):
    """Add a comment to a post."""
    db = get_db()
    
    post = await db.posts.find_one({"_id": ObjectId(post_id)})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    user = await db.users.find_one({"_id": ObjectId(user_id)})
    
    import datetime
    comment_doc = {
        "post_id": post_id,
        "user_id": user_id,
        "username": user["username"],
        "user_avatar": user.get("avatar_url", ""),
        "content": req.content,
        "upvotes": 0,
        "upvoted_by": [],
        "is_ai_answer": False,
        "created_at": datetime.datetime.now(datetime.timezone.utc),
    }
    
    result = await db.comments.insert_one(comment_doc)
    
    await db.posts.update_one(
        {"_id": ObjectId(post_id)},
        {"$inc": {"comments_count": 1, "xp_reward": 2}}
    )
    
    await db.users.update_one(
        {"_id": ObjectId(user_id)},
        {"$inc": {"xp": 5}}
    )
    
    return {
        "id": str(result.inserted_id),
        "message": "Comment added",
        "xp_earned": 5,
    }
