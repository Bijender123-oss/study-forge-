"""
StudyForge AI Routes
All AI-powered endpoints: explain, code analysis, projects, interviews, doubts.
"""
from fastapi import APIRouter, HTTPException, Depends, Query

from models import AIExplainRequest, AICodeRequest
from auth import get_current_user_id
from ai_service import (
    explain_content,
    analyze_code,
    generate_project_idea,
    mock_interview,
    solve_doubt,
)
from database import get_db
from bson.objectid import ObjectId

router = APIRouter(prefix="/api/ai", tags=["AI Services"])


@router.post("/explain")
async def ai_explain(req: AIExplainRequest, user_id: str = Depends(get_current_user_id)):
    """Explain educational content at different levels."""
    if not req.content.strip():
        raise HTTPException(status_code=400, detail="Content is required")
    
    result = await explain_content(
        content=req.content,
        level=req.level,
        language=req.language,
        is_code=req.is_code,
    )
    
    db = get_db()
    await db.users.update_one(
        {"_id": ObjectId(user_id)},
        {"$inc": {"xp": 5}}
    )
    
    return {
        "explanation": result,
        "level": req.level,
        "language": req.language,
        "xp_earned": 5,
    }


@router.post("/code")
async def ai_code(req: AICodeRequest, user_id: str = Depends(get_current_user_id)):
    """Analyze code: explain, dry-run, or improve."""
    if not req.code.strip():
        raise HTTPException(status_code=400, detail="Code is required")
    
    result = await analyze_code(
        code=req.code,
        language=req.language,
        action=req.action,
    )
    
    db = get_db()
    await db.users.update_one(
        {"_id": ObjectId(user_id)},
        {"$inc": {"xp": 10}}
    )
    
    return {
        "analysis": result,
        "action": req.action,
        "language": req.language,
        "xp_earned": 10,
    }


@router.post("/doubt")
async def ai_doubt(
    question: str = Query(..., min_length=1),
    context: str = Query(""),
    user_id: str = Depends(get_current_user_id),
):
    """Ask a doubt and get an AI explanation."""
    result = await solve_doubt(question=question, context=context)
    return {"question": question, "answer": result}


@router.get("/project-idea")
async def ai_project_idea(
    branch: str = Query("Computer Science"),
    skills: str = Query(""),
    difficulty: str = Query("beginner"),
    user_id: str = Depends(get_current_user_id),
):
    """Generate a project idea with step-by-step guide."""
    result = await generate_project_idea(branch=branch, skills=skills, difficulty=difficulty)
    return {"branch": branch, "difficulty": difficulty, "idea": result}


@router.get("/mock-interview")
async def ai_mock_interview(
    branch: str = Query("Computer Science"),
    company: str = Query(""),
    questions: int = Query(5, ge=1, le=10),
    user_id: str = Depends(get_current_user_id),
):
    """Generate mock interview questions for placement prep."""
    result = await mock_interview(branch=branch, company=company, question_count=questions)
    return {"branch": branch, "company": company if company else "General", "questions_count": questions, "interview": result}
