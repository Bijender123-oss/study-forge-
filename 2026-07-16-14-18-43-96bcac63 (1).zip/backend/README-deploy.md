# 🚀 StudyForge Backend — Render.com Deploy Guide (हिंदी)

यह guide आपको StudyForge backend को **Render.com** पर deploy करने में step-by-step help karega।

---

## 📋 Requirements (पहले से तैयार रखें)

| Item | Status |
|------|--------|
| MongoDB Atlas account (free) | ❌ अभी बनाना है |
| Render.com account (free) | ❌ अभी बनाना है |
| GitHub/GitLab account | ✅ हो तो आसान, nahi to manual upload bhi chalega |
| Gemini API key (optional) | 🟡 AI features ke liye chahiye |

---

## Step 1: MongoDB Atlas — Free Cluster बनाएं

> **ये step सबसे ज़रूरी है — MongoDB ke bina backend kaam nahi karega.**

1. **MongoDB.com पर जाएं:** https://www.mongodb.com
2. **Sign Up** करें (Google account se bhi kar sakte hain, free hai)
3. **Create a Cluster** पर click karein:
   - **Provider:** AWS (default)
   - **Region:** Mumbai (ap-south-1) ya jo aapke closest ho
   - **Tier:** **M0 Sandbox** (चुनें — ये फ्री है, हमेशा free रहेगा)
   - **Cluster Name:** `studyforge-cluster` (या जो मर्ज़ी)
4. **Create Cluster** करें — इसे बनने में 2-3 मिनट लगते हैं

### Connection String लेना (सबसे ज़रूरी step):

5. Cluster बन जाने पर **"Connect"** button पर click करें
6. **"Connect your application"** चुनें
7. **Drivers** चुनें: **Python** (कोई भी version)
8. **Connection string कॉपी करें** — कुछ इस तरह दिखेगा:
   ```
   mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/
   ```
9. **`<username>`** और **`<password>`** अपने MongoDB Atlas login credentials से replace करें
10. Connection string ke end में **`/studyforge?retryWrites=true&w=majority`** add करें
    - Final string कुछ इस तरह दिखेगा:
      ```
      mongodb+srv://mystudent:abc123@cluster0.abcde.mongodb.net/studyforge?retryWrites=true&w=majority
      ```

> ⚠️ **Password में special characters (@, $, :, /) हों तो URL encode करना पड़ेगा।**
> Simple password use karein (sirf letters + numbers) — headache nahi hoga.

---

## Step 2: Render.com पर Deploy करें

### 2A: Render.com अकाउंट बनाएं

1. **Render.com पर जाएं:** https://render.com
2. **Sign Up** — GitHub account se sign up karein (recommended)
3. Free plan automatically activate ho jayega

### 2B: Backend Repository तैयार करें

**Option A — GitHub (recommended):**
1. GitHub par ek **private/public repo** banayein
2. Backend files upload/push karein:
   ```bash
   cd studyforge/backend
   git init
   git add .
   git commit -m "Initial commit for Render deploy"
   git remote add origin https://github.com/YOUR_USERNAME/studyforge-backend.git
   git push -u origin main
   ```

**Option B — Manual Upload (no GitHub):**
1. Render पर **New Web Service** → **Deploy from files**
2. Zip upload karke bhi deploy kar sakte hain (render.yaml automatically detect hoga)

### 2C: Web Service Create करें

1. Render Dashboard पर **"New +"** → **"Web Service"** click करें
2. **Connect your repository** — apna GitHub repo select karein
3. Render **automatically `render.yaml` detect karega** → settings pre-filled ho jayengi
4. **Settings manually check karein:**
   - **Name:** `studyforge-api`
   - **Runtime:** `Python`
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn main:app --host 0.0.0.0 --port $PORT`
   - **Plan:** **Free** चुनें ($0/month)
5. **Environment Variables** set karein (niche Step 3 देखें)
6. **"Create Web Service"** button दबाएं

---

## Step 3: Environment Variables Set करें

Render Dashboard → studyforge-api → **Environment** tab → **Add Environment Variable**:

| Variable | Value | Example |
|----------|-------|---------|
| `MONGODB_URI` | 🔴 **MongoDB Atlas connection string** (Step 1 से) | `mongodb+srv://user:pass@cluster.mongodb.net/studyforge?retryWrites=true&w=majority` |
| `DATABASE_NAME` | `studyforge` (default) | `studyforge` |
| `JWT_SECRET` | 🟢 **Auto-generated** (render.yaml mein `generateValue: true`) | — |
| `JWT_ALGORITHM` | `HS256` | `HS256` |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | `1440` | `1440` |
| `FRONTEND_URL` | 🟡 **Netlify frontend ka URL** | `https://calm-twilight-b24553.netlify.app` |
| `GEMINI_API_KEY` | 🟡 **Optional** — Google AI Studio se key लें | `AIzaSy...` |

> 💡 **Render automatically `MONGODB_URI` me spaces ya special chars handle kar leta hai**, but safe rahein — password simple rakhein.

---

## Step 4: Deploy होने का इंतज़ार करें

1. **"Create Web Service"** click karne ke baad, Render:
   - Repository clone karega
   - Dependencies install karega (`pip install`)
   - App start karega

2. **पहला deploy 3-5 मिनट ले सकता है** (फ्री tier slow hota hai)

3. Success होने पर कुछ इस तरह दिखेगा:
   ```
   ✅ Build successful
   ✅ Deploying...
   Service is live 🎉
   ```

4. **Backend URL कॉपी करें** — कुछ इस तरह:
   ```
   https://studyforge-api.onrender.com
   ```

5. **Test करें:**
   ```bash
   # Health check — "healthy" आना चाहिए
   curl https://studyforge-api.onrender.com/health

   # API Docs — Swagger UI खुलना चाहिए
   # https://studyforge-api.onrender.com/docs
   ```

---

## Step 5: Frontend को Backend से Connect करें

Ab frontend (Netlify) ko naye backend URL se connect karna hai:

1. **StudyForge frontend project** mein `frontend/` folder mein **`.env.production`** file बनाएं (ya update karein):

   ```env
   VITE_API_URL=https://studyforge-api.onrender.com
   ```

2. Frontend **rebuild** karein:
   ```bash
   cd frontend
   npm run build
   ```

3. **Netlify** par redeploy karein:
   - Netlify Dashboard → apna site → **Deploy manually** → dist/ folder upload karein
   - Ya: Git-based deploy ho to push karein, auto-deploy ho jayega

4. **Verify करें** — frontend par login/signup try karein, data load hona चाहिए

---

## 🎯 Success Checklist

- [ ] MongoDB Atlas cluster बन गया?
- [ ] Connection string में `<username>` और `<password>` replace किया?
- [ ] Render.com पर web service create हो गई?
- [ ] Environment variables set हो गए?
- [ ] Deploy successful — `https://studyforge-api.onrender.com/health` → `{"status":"healthy"}`
- [ ] Frontend `.env.production` update किया?
- [ ] Frontend rebuild + redeploy किया?
- [ ] Login/signup + features working?

---

## 🐛 Common Issues & Fixes

### ❌ "MongoDB connection timeout"
- **Cause:** MongoDB Atlas IP whitelist
- **Fix:** MongoDB Atlas → Network Access → **Add IP Address** → `0.0.0.0/0` (allow all — Render dynamic IP pe hai)
- **Ya:** ✅ `Allow Access from Anywhere` button dabayein

### ❌ "CORS policy: No 'Access-Control-Allow-Origin'"
- **Cause:** Frontend URL mismatch
- **Fix:** Check karein `FRONTEND_URL` env variable sahi hai — Render Dashboard → Environment mein check karein

### ❌ "502 Bad Gateway" ya "Application Error"
- **Cause:** Port mismatch
- **Fix:** Render automatically `$PORT` var set karta hai. render.yaml mein `--port $PORT` likha hai, verify karein

### ❌ "pytesseract not found"
- **Cause:** OCR library system par installed nahi
- **Fix:** Notes upload feature ke liye hai — production mein use nahi ho raha. Safe to ignore.

### ❌ Build fail ho raha hai
- **Cause:** Python version ya dependency issue
- **Fix:** Render Dashboard → Environment → `PYTHON_VERSION` = `3.11.6` add karein

---

## 📁 Files in this Deployment

| File | Purpose |
|------|---------|
| `render.yaml` | Render.com auto-detect configuration |
| `main.py` | FastAPI app with CORS setup |
| `config.py` | Environment variables loader |
| `database.py` | MongoDB (Motor) connection |
| `requirements.txt` | Python dependencies |
| `.env.example` | Environment variables template with instructions |
| `routes/` | API route handlers (auth, posts, notes, AI, etc.) |
| `auth.py` | JWT authentication |
| `ai_service.py` | Gemini AI integration |

---

> **Need help?** Render docs: https://render.com/docs
> MongoDB Atlas docs: https://www.mongodb.com/docs/atlas/
> StudyForge GitHub: https://github.com/studyforge
