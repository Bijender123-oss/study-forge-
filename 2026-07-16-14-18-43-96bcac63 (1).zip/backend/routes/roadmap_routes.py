"""
StudyForge Roadmap Routes
Branch-wise learning paths with progress tracking.
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional

from database import get_db
from auth import get_current_user_id
from bson.objectid import ObjectId

router = APIRouter(prefix="/api/roadmaps", tags=["Roadmaps"])


@router.get("/")
async def get_roadmaps(
    branch: Optional[str] = None,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=50),
):
    """Get all roadmaps, optionally filtered by branch."""
    db = get_db()
    
    filter_query = {}
    if branch:
        filter_query["branch"] = branch
    
    total = await db.roadmaps.count_documents(filter_query)
    cursor = db.roadmaps.find(filter_query).sort("votes", -1)
    cursor = cursor.skip((page - 1) * limit).limit(limit)
    
    roadmaps = []
    async for doc in cursor:
        roadmaps.append({
            "id": str(doc["_id"]),
            "title": doc["title"],
            "branch": doc["branch"],
            "description": doc.get("description", ""),
            "created_by": doc.get("created_by", ""),
            "votes": doc.get("votes", 0),
            "difficulty": doc.get("difficulty", "beginner"),
            "estimated_duration": doc.get("estimated_duration", ""),
            "topics_count": len(doc.get("topics", [])),
            "is_official": doc.get("is_official", False),
            "created_at": doc["created_at"].isoformat() if doc.get("created_at") else None,
        })
    
    return {"roadmaps": roadmaps, "total": total, "page": page, "limit": limit}


@router.get("/{roadmap_id}")
async def get_roadmap(roadmap_id: str):
    """Get a full roadmap with all topics."""
    db = get_db()
    
    roadmap = await db.roadmaps.find_one({"_id": ObjectId(roadmap_id)})
    if not roadmap:
        raise HTTPException(status_code=404, detail="Roadmap not found")
    
    topics = []
    for topic in roadmap.get("topics", []):
        topics.append({
            "title": topic.get("title", ""),
            "description": topic.get("description", ""),
            "order": topic.get("order", 0),
            "resources": topic.get("resources", []),
            "tasks": topic.get("tasks", []),
            "estimated_hours": topic.get("estimated_hours", 1.0),
        })
    
    return {
        "id": str(roadmap["_id"]),
        "title": roadmap["title"],
        "branch": roadmap["branch"],
        "description": roadmap.get("description", ""),
        "topics": topics,
        "created_by": roadmap.get("created_by", ""),
        "votes": roadmap.get("votes", 0),
        "difficulty": roadmap.get("difficulty", "beginner"),
        "estimated_duration": roadmap.get("estimated_duration", ""),
        "is_official": roadmap.get("is_official", False),
    }
