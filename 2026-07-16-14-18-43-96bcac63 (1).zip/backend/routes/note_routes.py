"""
StudyForge Notes Routes
Upload, summarize, and manage study notes.
"""
from fastapi import APIRouter, HTTPException, Depends, UploadFile, File, Form
from typing import Optional

from database import get_db
from models import NoteUploadRequest
from auth import get_current_user_id
from ai_service import summarize_notes
from bson.objectid import ObjectId

router = APIRouter(prefix="/api/notes", tags=["Notes"])


@router.post("/upload")
async def upload_note(
    title: str = Form(...),
    description: str = Form(""),
    content: str = Form(""),
    tags: str = Form(""),
    is_public: bool = Form(True),
    file: Optional[UploadFile] = File(None),
    user_id: str = Depends(get_current_user_id),
):
    """
    Upload a study note.
    
    Either provide:
    - A text content directly, OR
    - A PDF/image file to upload
    
    AI will automatically generate summary, flashcards, and quiz.
    """
    db = get_db()
    import datetime
    
    file_url = ""
    file_type = "text"
    extracted_text = content
    
    # Handle file upload
    if file:
        filename = file.filename.lower()
        if filename.endswith(".pdf"):
            file_type = "pdf"
        elif any(filename.endswith(ext) for ext in [".png", ".jpg", ".jpeg", ".webp", ".gif"]):
            file_type = "image"
        else:
            file_type = "text"
        
        # Save file locally (in production, upload to cloud storage)
        import os
        upload_dir = "uploads/notes"
        os.makedirs(upload_dir, exist_ok=True)
        
        file_path = f"{upload_dir}/{datetime.datetime.now().timestamp()}_{file.filename}"
        with open(file_path, "wb") as f:
            content_bytes = await file.read()
            f.write(content_bytes)
        
        file_url = file_path
        extracted_text = content  # For now; in production, use OCR for PDFs/images
    
    # Parse tags from comma-separated string
    tag_list = [t.strip() for t in tags.split(",") if t.strip()]
    
    # Generate AI summary if content is provided
    ai_summary = ""
    ai_flashcards = []
    ai_quiz = []
    
    if extracted_text and len(extracted_text) > 20:
        ai_result = await summarize_notes(extracted_text)
        if isinstance(ai_result, dict):
            ai_summary = ai_result.get("summary", "")
            ai_flashcards = ai_result.get("flashcards", [])
            ai_quiz = ai_result.get("quiz", [])
    
    note_doc = {
        "user_id": user_id,
        "title": title,
        "description": description,
        "file_url": file_url,
        "file_type": file_type,
        "extracted_text": extracted_text,
        "ai_summary": ai_summary,
        "ai_flashcards": ai_flashcards,
        "ai_quiz": ai_quiz,
        "tags": tag_list,
        "is_public": is_public,
        "downloads": 0,
        "created_at": datetime.datetime.now(datetime.timezone.utc),
    }
    
    result = await db.notes.insert_one(note_doc)
    
    # Award XP
    await db.users.update_one(
        {"_id": ObjectId(user_id)},
        {"$inc": {"xp": 25}}
    )
    
    return {
        "id": str(result.inserted_id),
        "title": title,
        "ai_summary": ai_summary,
        "flashcards_count": len(ai_flashcards),
        "quiz_count": len(ai_quiz),
        "xp_earned": 25,
        "message": "Note uploaded and processed successfully!",
    }


@router.get("/")
async def get_notes(
    page: int = 1,
    limit: int = 20,
    tag: Optional[str] = None,
    user_id: str = Depends(get_current_user_id),
):
    """Get notes (own public notes + all public notes)."""
    db = get_db()
    
    filter_query = {"is_public": True}
    if tag:
        filter_query["tags"] = tag
    
    total = await db.notes.count_documents(filter_query)
    
    cursor = db.notes.find(filter_query).sort("created_at", -1)
    cursor = cursor.skip((page - 1) * limit).limit(limit)
    
    notes = []
    async for doc in cursor:
        notes.append({
            "id": str(doc["_id"]),
            "user_id": doc["user_id"],
            "title": doc["title"],
            "description": doc.get("description", ""),
            "file_type": doc.get("file_type", ""),
            "ai_summary": doc.get("ai_summary", ""),
            "tags": doc.get("tags", []),
            "downloads": doc.get("downloads", 0),
            "created_at": doc["created_at"].isoformat() if doc.get("created_at") else None,
        })
    
    return {"notes": notes, "total": total, "page": page, "limit": limit}


@router.get("/{note_id}")
async def get_note(note_id: str):
    """Get a single note with full AI content."""
    db = get_db()
    
    note = await db.notes.find_one({"_id": ObjectId(note_id)})
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    
    return {
        "id": str(note["_id"]),
        "user_id": note["user_id"],
        "title": note["title"],
        "description": note.get("description", ""),
        "file_url": note.get("file_url", ""),
        "file_type": note.get("file_type", ""),
        "extracted_text": note.get("extracted_text", ""),
        "ai_summary": note.get("ai_summary", ""),
        "ai_flashcards": note.get("ai_flashcards", []),
        "ai_quiz": note.get("ai_quiz", []),
        "tags": note.get("tags", []),
        "downloads": note.get("downloads", 0),
        "created_at": note["created_at"].isoformat() if note.get("created_at") else None,
    }
