"""
StudyForge Leaderboard Routes
Gamification: XP, levels, badges, leaderboard.
"""
from fastapi import APIRouter, Depends, Query

from database import get_db
from auth import get_current_user_id

router = APIRouter(prefix="/api/leaderboard", tags=["Gamification"])


@router.get("/")
async def get_leaderboard(
    limit: int = Query(50, ge=1, le=100),
    branch: str = Query(""),
):
    """Get top users by XP / level."""
    db = get_db()
    
    filter_query = {}
    if branch:
        filter_query["branch"] = branch
    
    cursor = db.users.find(filter_query).sort("xp", -1).limit(limit)
    
    users = []
    rank = 1
    async for doc in cursor:
        users.append({
            "rank": rank,
            "username": doc["username"],
            "full_name": doc.get("full_name", ""),
            "avatar_url": doc.get("avatar_url", ""),
            "branch": doc.get("branch", ""),
            "year": doc.get("year", 1),
            "xp": doc.get("xp", 0),
            "level": doc.get("level", 1),
            "badges": doc.get("badges", []),
            "reputation": doc.get("reputation", 0),
        })
        rank += 1
    
    return {"leaderboard": users, "total": len(users)}


@router.get("/my-rank")
async def get_my_rank(user_id: str = Depends(get_current_user_id)):
    """Get current user's rank and stats."""
    db = get_db()
    from bson.objectid import ObjectId
    
    user = await db.users.find_one({"_id": ObjectId(user_id)})
    if not user:
        return {"error": "User not found"}
    
    # Count users with more XP
    higher_count = await db.users.count_documents({"xp": {"$gt": user.get("xp", 0)}})
    total_users = await db.users.count_documents({})
    
    return {
        "rank": higher_count + 1,
        "total_users": total_users,
        "username": user["username"],
        "xp": user.get("xp", 0),
        "level": user.get("level", 1),
        "badges": user.get("badges", []),
        "reputation": user.get("reputation", 0),
        "next_level_xp": (user.get("level", 1) + 1) * 100,
        "xp_to_next_level": ((user.get("level", 1) + 1) * 100) - user.get("xp", 0),
    }
