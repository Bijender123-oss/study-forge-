"""
StudyForge Study Room Routes
Group study sessions with chat + timer.
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from bson.objectid import ObjectId

from database import get_db
from auth import get_current_user_id

router = APIRouter(prefix="/api/study-rooms", tags=["Study Rooms"])


@router.get("/")
async def get_study_rooms():
    """Get all active study rooms."""
    db = get_db()
    
    cursor = db.study_rooms.find({"is_active": True}).sort("created_at", -1)
    rooms = []
    async for doc in cursor:
        rooms.append({
            "id": str(doc["_id"]),
            "name": doc["name"],
            "description": doc.get("description", ""),
            "created_by": doc.get("created_by", ""),
            "members_count": len(doc.get("members", [])),
            "focus_timer": doc.get("focus_timer", 0),
            "tags": doc.get("tags", []),
            "created_at": doc["created_at"].isoformat() if doc.get("created_at") else None,
        })
    
    return {"rooms": rooms}


@router.post("/")
async def create_study_room(
    name: str = Query(..., min_length=1, max_length=100),
    description: str = Query(""),
    focus_timer: int = Query(25, ge=1, le=180),
    tags: str = Query(""),
    user_id: str = Depends(get_current_user_id),
):
    """Create a new study room."""
    db = get_db()
    import datetime
    
    tag_list = [t.strip() for t in tags.split(",") if t.strip()]
    
    room_doc = {
        "name": name,
        "description": description,
        "created_by": user_id,
        "members": [user_id],
        "focus_timer": focus_timer,
        "is_active": True,
        "tags": tag_list,
        "created_at": datetime.datetime.now(datetime.timezone.utc),
    }
    
    result = await db.study_rooms.insert_one(room_doc)
    
    return {
        "id": str(result.inserted_id),
        "name": name,
        "message": "Study room created!",
    }


@router.post("/{room_id}/join")
async def join_study_room(room_id: str, user_id: str = Depends(get_current_user_id)):
    """Join a study room."""
    db = get_db()
    
    room = await db.study_rooms.find_one({"_id": ObjectId(room_id)})
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    if user_id not in room.get("members", []):
        await db.study_rooms.update_one(
            {"_id": ObjectId(room_id)},
            {"$push": {"members": user_id}}
        )
    
    return {"message": "Joined the room!"}
