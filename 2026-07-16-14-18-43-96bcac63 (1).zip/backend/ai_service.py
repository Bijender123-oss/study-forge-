"""
StudyForge AI Service
Integrates with Google Gemini API for:
- Content explanation (multi-level, multi-language)
- Code explanation & dry-run
- Note summarization & flashcard generation
- Quiz generation
- Project idea generation
- Mock interview questions
"""
import os
import httpx
import json
from typing import List, Optional

from config import GEMINI_API_KEY

# Gemini API endpoint
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent"


async def call_gemini(prompt: str, system_instruction: str = "") -> str:
    """
    Make a request to Gemini API.
    
    Args:
        prompt: The user message / question
        system_instruction: System-level instruction for behavior
    
    Returns:
        Generated text response
    """
    if not GEMINI_API_KEY:
        return "⚠️ AI service not configured. Please set GEMINI_API_KEY in .env file."

    headers = {"Content-Type": "application/json"}
    
    contents = []
    if system_instruction:
        contents.append({"role": "user", "parts": [{"text": system_instruction}]})
    
    contents.append({"role": "user", "parts": [{"text": prompt}]})

    payload = {
        "contents": contents,
        "generationConfig": {
            "temperature": 0.7,
            "maxOutputTokens": 2048,
            "topP": 0.9,
        }
    }

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                f"{GEMINI_URL}?key={GEMINI_API_KEY}",
                headers=headers,
                json=payload,
            )
            response.raise_for_status()
            data = response.json()
            
            # Extract text from Gemini response
            candidates = data.get("candidates", [])
            if candidates:
                parts = candidates[0].get("content", {}).get("parts", [])
                if parts:
                    return parts[0].get("text", "")
            return "❌ No response from AI."
    except Exception as e:
        return f"❌ AI Error: {str(e)}"


# ──────────────────────────────────────────────
# EXPLANATION ENGINE
# ──────────────────────────────────────────────

async def explain_content(
    content: str,
    level: str = "beginner",
    language: str = "hinglish",
    is_code: bool = False,
) -> str:
    """
    Explain educational content at different levels.
    
    Args:
        content: The text or code to explain
        level: "beginner" | "college" | "interview"
        language: "english" | "hindi" | "hinglish"
        is_code: True if explaining code
    
    Returns:
        AI-generated explanation
    """
    level_prompts = {
        "beginner": (
            "Explain in VERY SIMPLE terms. Use everyday analogies and real-life examples. "
            "Assume the student has zero background knowledge. Break it down step by step. "
            "Keep it short, clear, and friendly."
        ),
        "college": (
            "Explain at a college/university level. Cover the core concepts, "
            "relevant theories, and practical applications. Use proper terminology "
            "but still make it understandable."
        ),
        "interview": (
            "Explain at an interview/advanced level. Cover edge cases, underlying mechanisms, "
            "performance implications, and common interview questions related to this topic. "
            "Be thorough and technical."
        ),
    }
    
    lang_instructions = {
        "english": "Use English only.",
        "hindi": "Use Hindi (हिंदी) only. Explain everything in Hindi.",
        "hinglish": (
            "Use Hinglish (Hindi + English mixed, written in Devanagari or Roman script). "
            "Explain in simple Hinglish that a beginner student would understand. "
            "Use real-life examples and step-by-step breakdowns."
        ),
    }

    code_instruction = ""
    if is_code:
        code_instruction = (
            "\nAlso provide:\n"
            "1. A real-life example of where this code is used\n"
            "2. Step-by-step breakdown of what each line does\n"
            "3. Explain each line of the code with its purpose\n"
            "4. Expected output and how it works\n"
        )

    system = (
        f"You are an expert teacher and study assistant. "
        f"{level_prompts.get(level, level_prompts['beginner'])} "
        f"{lang_instructions.get(language, lang_instructions['english'])}"
        f"{code_instruction}"
    )

    prompt = f"Explain this {'code' if is_code else 'content'}:\n\n{content}"
    return await call_gemini(prompt, system)


# ──────────────────────────────────────────────
# CODE LAB
# ──────────────────────────────────────────────

async def analyze_code(code: str, language: str = "python", action: str = "explain") -> str:
    """
    Analyze code: explain, dry-run, or suggest improvements.
    
    Args:
        code: The source code to analyze
        language: Programming language
        action: "explain" | "dry-run" | "improve"
    
    Returns:
        AI analysis result
    """
    prompts = {
        "explain": (
            f"Explain the following {language} code line-by-line. "
            "For each line, describe its purpose, what it does, and any important syntax. "
            "Also include a real-life analogy and expected output."
        ),
        "dry-run": (
            f"Perform a dry run / trace execution of this {language} code. "
            "Show the state of all variables at each step, like a debugger. "
            "Use a table format: Step | Line | Variable Changes | Output"
        ),
        "improve": (
            f"Review this {language} code and suggest improvements. "
            "Cover: readability, performance, best practices, error handling, "
            "and potential bugs. Provide the improved code too."
        ),
    }

    prompt = f"{prompts.get(action, prompts['explain'])}\n\n```{language}\n{code}\n```"
    system = "You are an expert programming tutor. Be thorough and beginner-friendly."
    return await call_gemini(prompt, system)


# ──────────────────────────────────────────────
# NOTE SUMMARIZATION
# ──────────────────────────────────────────────

async def summarize_notes(text: str) -> dict:
    """
    Generate summary, flashcards, and quiz from notes text.
    
    Args:
        text: Extracted text from notes
    
    Returns:
        Dict with summary, flashcards, and quiz
    """
    system = (
        "You are a study assistant. Analyze the given study notes and produce:\n"
        "1. A concise summary (3-5 sentences)\n"
        "2. 5 flashcards (question-answer pairs) for revision\n"
        "3. A 5-question multiple choice quiz (each with 4 options and the correct answer)\n\n"
        "Output as valid JSON with this exact structure:\n"
        '{"summary": "...", "flashcards": [{"question": "...", "answer": "..."}], '
        '"quiz": [{"question": "...", "options": ["a","b","c","d"], "correct_answer": "a"}]}'
    )
    
    result = await call_gemini(f"Notes to analyze:\n\n{text}", system)
    
    # Try to parse JSON from response
    try:
        # Find JSON in the response (Gemini might wrap it in markdown)
        json_str = result
        if "```json" in result:
            json_str = result.split("```json")[1].split("```")[0].strip()
        elif "```" in result:
            json_str = result.split("```")[1].split("```")[0].strip()
        return json.loads(json_str)
    except (json.JSONDecodeError, IndexError):
        # Fallback: return raw text
        return {
            "summary": result,
            "flashcards": [],
            "quiz": [],
        }


# ──────────────────────────────────────────────
# PROJECT IDEAS
# ──────────────────────────────────────────────

async def generate_project_idea(branch: str, skills: str = "", difficulty: str = "beginner") -> str:
    """Generate a project idea with step-by-step guide."""
    prompt = (
        f"Suggest a {difficulty}-level project idea for a {branch} student. "
        f"Skills: {skills if skills else 'any relevant skills'}. "
        "Provide:\n"
        "1. Project title and brief description\n"
        "2. Technologies needed\n"
        "3. Step-by-step implementation tasks (5-8 steps)\n"
        "4. Key code snippets for each step\n"
        "5. What the final output looks like\n"
        "Make it practical and portfolio-worthy."
    )
    system = "You are a project mentor for engineering students."
    return await call_gemini(prompt, system)


# ──────────────────────────────────────────────
# MOCK INTERVIEW
# ──────────────────────────────────────────────

async def mock_interview(branch: str, company: str = "", question_count: int = 5) -> str:
    """Generate mock interview questions for placement prep."""
    prompt = (
        f"Generate {question_count} mock interview questions for a {branch} student. "
        f"Target company: {company if company else 'general tech companies'}. "
        "For each question provide:\n"
        "1. The question\n"
        "2. What the interviewer is looking for\n"
        "3. A model answer\n"
        "4. Common mistakes to avoid\n"
        "Cover both technical and HR questions."
    )
    system = "You are a placement coordinator and HR interviewer."
    return await call_gemini(prompt, system)


# ──────────────────────────────────────────────
# DOUBT SOLVER
# ──────────────────────────────────────────────

async def solve_doubt(question: str, context: str = "") -> str:
    """
    Answer a student's doubt with clear explanation.
    
    Args:
        question: The doubt/question text
        context: Optional context (branch, subject, etc.)
    
    Returns:
        Detailed answer
    """
    prompt = (
        f"Answer this student's doubt clearly:\n\n"
        f"Question: {question}\n"
        f"Context: {context if context else 'General'}\n\n"
        "Provide:\n"
        "1. Direct answer (2-3 sentences)\n"
        "2. Detailed explanation\n"
        "3. Example if applicable\n"
        "4. Related concepts to study"
    )
    system = "You are a helpful tutor. Be concise yet thorough."
    return await call_gemini(prompt, system)
