"""
StudyForge Community — Backend API
FastAPI application entry point.

Run: uvicorn main:app --reload --port 8000
Docs: http://localhost:8000/docs
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from config import HOST, PORT
from database import connect_db, close_db
from routes.auth_routes import router as auth_router
from routes.post_routes import router as post_router
from routes.note_routes import router as note_router
from routes.ai_routes import router as ai_router
from routes.roadmap_routes import router as roadmap_router
from routes.studyroom_routes import router as studyroom_router
from routes.leaderboard_routes import router as leaderboard_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Handle startup and shutdown events."""
    # Startup: connect to database
    await connect_db()
    yield
    # Shutdown: close connection
    await close_db()


# Create FastAPI app
app = FastAPI(
    title="StudyForge Community API",
    description="AI-powered community learning platform for students.",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS — allow frontend (both dev and production) to call API
import os
FRONTEND_URL = os.getenv("FRONTEND_URL", "https://calm-twilight-b24553.netlify.app")

# Collect all allowed origins
ALLOWED_ORIGINS = [
    "http://localhost:5173",                                # Vite React dev server
    "http://localhost:3000",                                # Alternative React port
    "http://127.0.0.1:5173",
    "http://127.0.0.1:3000",
]

# Add production frontend URL if set
if FRONTEND_URL:
    ALLOWED_ORIGINS.append(FRONTEND_URL)
    # Also add https version if FRONTEND_URL is http
    if FRONTEND_URL.startswith("http://"):
        ALLOWED_ORIGINS.append(FRONTEND_URL.replace("http://", "https://"))

# Allow Netlify deploy previews (wildcard via regex)
# Note: *.onrender.com & *.netlify.app are covered by allow_origin_regex
# For simple origins, use allow_origins; for patterns, use allow_origin_regex
# Adding the main frontend URL explicitly in origins above

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_origin_regex=r"https://.*\.onrender\.com|https://.*\.netlify\.app",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register all route handlers
app.include_router(auth_router)
app.include_router(post_router)
app.include_router(note_router)
app.include_router(ai_router)
app.include_router(roadmap_router)
app.include_router(studyroom_router)
app.include_router(leaderboard_router)


@app.get("/")
async def root():
    """Health check endpoint."""
    return {
        "app": "StudyForge Community",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs",
    }


@app.get("/health")
async def health():
    """Health check for monitoring."""
    return {"status": "healthy"}


# Run the app directly (also works with `uvicorn main:app`)
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host=HOST, port=PORT, reload=True)
