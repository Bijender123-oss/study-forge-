"""
StudyForge Database Connection
Handles MongoDB connection using Motor (async driver).
"""
from motor.motor_asyncio import AsyncIOMotorClient
from config import MONGODB_URI, DATABASE_NAME

# Global client & db references
client = None
db = None

async def connect_db():
    """Initialize MongoDB connection."""
    global client, db
    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[DATABASE_NAME]
    print(f"✅ Connected to MongoDB: {DATABASE_NAME}")

    # Create indexes for faster queries
    await db.users.create_index("email", unique=True)
    await db.users.create_index("username", unique=True)
    await db.posts.create_index([("created_at", -1)])
    await db.posts.create_index([("tags", 1)])
    await db.notes.create_index([("user_id", 1), ("created_at", -1)])
    await db.comments.create_index([("post_id", 1), ("created_at", -1)])
    await db.roadmaps.create_index([("branch", 1)])

    print("✅ Indexes created")

async def close_db():
    """Close MongoDB connection."""
    global client
    if client:
        client.close()
        print("🔌 MongoDB connection closed")

def get_db():
    """Get database instance."""
    if db is None:
        raise RuntimeError("Database not connected. Call connect_db() first.")
    return db
